# stock-price-prediction-by-ML

This is FIN3210 Final Project in CUHK(SZ) on Fall 2022.
Our objective is to apply machine learning and deep learning models to predicting stocks' return.
We start with downloading Alpha158 dataset.
Then, we try different models and build strategies to see their backtest performance.
Finally, we select a bunch of models to conduct a strategy-based portfolio.
